﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//Serial 导入 
using System.IO.Ports;

//enum引用


//创建新线程
using System.Threading;

namespace modbus
{
    public partial class Form1 : Form
    {
        //全局变量

        //UART = 0 or TCP/IP = 1选择
        byte UART_OR_TCP = 0;

        //RTU = 0 or ASCII = 1选择
        byte RTU_OR_ASCII = 0;

        //03 06功能码接收数据标志
        byte func_code03_06 = 0;

        //显示 03 06功能码接收数据标志
        byte func_code03_06_show = 0;

        //自动扫描串口次数标记
        byte aotu_search_serail_cnt_flag = 0;

        //定时器 设定值 计数值
        //最少接收7个字符 
        /*
        7字符时间计算: 例如
        波特率 9600bit/S
        每位传输的时间t = 1000 000us/9600 = 104us
        一个字节的传输时间 T=10*t = 104us*10 = 1040us
        7字符时间 = 7*1040 = 7168 = 7ms
        */
        int set_times_ms = 0;
        int get_times_ms = 0;
        byte times_ms_overflow_flag = 0;

        //串口最大端口号扫描次数
        byte com_search_limit_max = 20;

        //byte[] 数组最大数据长度定义
        static int BYTE_CODE_MAX = 128;

        //串口数据接收
        byte[] rec_data = new byte[BYTE_CODE_MAX];

        //循环队列实例
        loop_queue_list<byte> queue = new loop_queue_list<byte>(BYTE_CODE_MAX);

        //CRC计算实例
        cal_check_list cal_crc = new cal_check_list();

        //委托调用
        delegate void Serial_Rece_Show();
        Serial_Rece_Show My_Serial_Rece_Show;

        public Form1()
        {
            InitializeComponent();

            //关闭跨线程检测
            //否则串口无法接收数据
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;

            //委托实例化
            //否则无法使用委托
            My_Serial_Rece_Show = new Serial_Rece_Show(My_Serial_Rece_ShowBox);

            //串口接收事件需自己手动注册
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(Div_Rece_Data);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //清除 功能码 03 06内容
            clear_func_03();
            clear_func_06();

            //初始化端口名、波特率
            comboBox1.Text = "COM1";
            serialPort1.PortName = comboBox1.Text;

            comboBox2.Text = "9600";
            serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text, 10);

            //串口接收数据量触发阈值
            serialPort1.ReceivedBytesThreshold = 1;

        }

        /*无用操作区域#################################################################################开始*/

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        /*无用操作区域#################################################################################结束*/

        private void button1_Click(object sender, EventArgs e)
        {
            if (UART_OR_TCP == 0)//串口操作相关
            {
                Div_Auto_Search_Port(serialPort1, comboBox1, com_search_limit_max);
            }
            aotu_search_serail_cnt_flag++;
            if (aotu_search_serail_cnt_flag % 2 == 0)
            {
                button1.Text = "扫描端口";
                aotu_search_serail_cnt_flag = 0;
            }
            else
            {
                button1.Text = "已扫描";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (UART_OR_TCP == 0)//串口操作相关
                {
                    Div_Check_Serail_IsOpen(serialPort1, comboBox1, button2);

                    //信息显示
                    if (func_code03_06_show == 3)
                    {
                        clear_func_03();
                        clear_func_06();

                        Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_DF, textBox10);
                        Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_DF, textBox15);

                        func_code03_06_show = 0;
                    }
                    if (func_code03_06_show == 4)
                    {
                        Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_TE, textBox10);
                        Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_TE, textBox15);

                        func_code03_06_show = 0;
                    }
                }
            }
            catch
            {

            }
        }

        //适用MODBUS RTU 方式的 功能码 03 06
        public int Modbus_RTU_Send(TextBox addr_textbox, TextBox reg_textbox,TextBox num_textbox,byte[] rec_data, byte func_num)
        {
            byte temp_slaveadr = 0;
            int temp_regaddr = 0;
            int temp_regnum = 0;

            int temp_crc = 0;

            int temp_len = 0;
            byte[] temp_data = new byte[8];

            //获取数据暂存
            temp_slaveadr = Convert.ToByte(addr_textbox.Text, 16);
            temp_regaddr = Convert.ToUInt16(reg_textbox.Text, 16);
            temp_regnum = Convert.ToUInt16(num_textbox.Text, 16);

            //加载数据
            temp_data[temp_len++] = temp_slaveadr;
            temp_data[temp_len++] = func_num;
            temp_data[temp_len++] = (byte)((temp_regaddr & 0xFFFF) >> 8);
            temp_data[temp_len++] = (byte)(temp_regaddr & 0xFF);
            temp_data[temp_len++] = (byte)((temp_regnum & 0xFFFF) >> 8);
            temp_data[temp_len++] = (byte)(temp_regnum & 0xFF);

            //CRC校验
            temp_crc = cal_crc.Div_Data_Check_Crc(temp_data, temp_len);

            temp_data[temp_len++] = (byte)((temp_crc& 0xFFFF) >> 8);
            temp_data[temp_len++] = (byte)(temp_crc & 0xFF);

            //数据拷贝
            Buffer.BlockCopy(temp_data, 0, rec_data, 0, temp_len);

            return temp_len;
        }

        public byte hex_to_ascii(byte bHex)
        {	
            if((bHex>=0)&&(bHex<=9))bHex += 0x30;	
            else if((bHex>=10)&&(bHex<=15))bHex += 0x37;	
            else bHex = 0xff;

            return bHex;
        }

        public byte ascii_to_hex(byte bChar)
        {
            if((bChar>=0x30)&&(bChar<=0x39))bChar -= 0x30;	
            else if((bChar>=0x41)&&(bChar<=0x46))bChar -= 0x37;		
            else if((bChar>=0x61)&&(bChar<=0x66))bChar -= 0x57;	
            else bChar = 0xff;

            return bChar;
         }

        //适用MODBUS ASCII 方式的 功能码 03 06
        public int Modbus_ASCII_Send(TextBox addr_textbox, TextBox reg_textbox, TextBox num_textbox, byte[] rec_data, byte func_num)
        {
            byte temp_slaveadr = 0;
            int temp_regaddr = 0;
            int temp_regnum = 0;

            byte temp_crc = 0;

            int temp_len = 0;
            byte[] temp_data = new byte[20];

            //获取数据暂存
            temp_slaveadr = Convert.ToByte(addr_textbox.Text, 16);
            temp_regaddr = Convert.ToUInt16(reg_textbox.Text, 16);
            temp_regnum = Convert.ToUInt16(num_textbox.Text, 16);

            //加载数据
            temp_data[temp_len++] = (byte)':';

            //地址
            temp_data[temp_len++] = hex_to_ascii((byte)((temp_slaveadr & 0xFF) >> 4));
            temp_data[temp_len++] = hex_to_ascii((byte)((temp_slaveadr & 0xFF) % 16));

            //功能码
            temp_data[temp_len++] = hex_to_ascii((byte)((func_num & 0xFF) >> 4));
            temp_data[temp_len++] = hex_to_ascii((byte)((func_num & 0xFF) % 16));

            //寄存器地址
            temp_data[temp_len++] = hex_to_ascii((byte)(((temp_regaddr & 0xFFFF) >> 8) >> 4));
            temp_data[temp_len++] = hex_to_ascii((byte)(((temp_regaddr & 0xFFFF) >> 8) % 16));
            temp_data[temp_len++] = hex_to_ascii((byte)((temp_regaddr & 0xFF) >> 4));
            temp_data[temp_len++] = hex_to_ascii((byte)((temp_regaddr & 0xFF) % 16));

            //数量、个数
            temp_data[temp_len++] = hex_to_ascii((byte)(((temp_regnum & 0xFFFF) >> 8) >> 4));
            temp_data[temp_len++] = hex_to_ascii((byte)(((temp_regnum & 0xFFFF) >> 8) % 16));
            temp_data[temp_len++] = hex_to_ascii((byte)((temp_regnum & 0xFF) >> 4));
            temp_data[temp_len++] = hex_to_ascii((byte)((temp_regnum & 0xFF) % 16));

            //CRC校验
            temp_crc = CAL_LQR(temp_data, temp_len-1);

            temp_data[temp_len++] = hex_to_ascii((byte)((temp_crc & 0xFF) >> 4));
            temp_data[temp_len++] = hex_to_ascii((byte)((temp_crc & 0xFF) % 16));

            temp_data[temp_len++] = (byte)'\r';
            temp_data[temp_len++] = (byte)'\n';

            //数据拷贝
            Buffer.BlockCopy(temp_data, 0, rec_data, 0, temp_len);

            return temp_len;
        }

        public void func_0306_deal_first(TextBox addr_textbox, TextBox reg_textbox, TextBox num_textbox,
            byte func_num, RadioButton ch_radioButton, SerialPort ch_serialport, TextBox show_textbox)
        {
            int temp_len = 0;
            byte[] temp_data = new byte[20];
            string[] str = new string[20];

            //只有打开串口 or 打开TCP/IP才能发送数据
            //TCP/IP 暂未实现
            if (ch_serialport.IsOpen)
            {
                try
                {
                     //设备(10进制 2) 寄存器地址(16进制 0001) 数量(10进制 2) 都不为空 返回的有效数据为16进制 0001
                    if (ch_radioButton.Checked)//RTU方式发送数据
                    {
                        temp_len = Modbus_RTU_Send(addr_textbox, reg_textbox, num_textbox, temp_data, func_num);
                    }
                    else//ASCII方式发送数据
                    {
                        temp_len = Modbus_ASCII_Send(addr_textbox, reg_textbox, num_textbox, temp_data, func_num);
                    }
                    ch_serialport.Write(temp_data, 0, temp_len);                    //发送
                    Data_Byte_To_String(temp_data, str, temp_len, show_textbox);    //显示
                   
                }
                catch
                {

                }
            }
        }

        //处理接收到的数据
        public void func_0306_deal_recdata_first()
        { 
            int temp_len = 0;
            int sum_RTU_crc = 0;
            int rec_RTU_crc = 0;

            byte sum_ASCII_crc = 0;
            byte rec_ASCII_crc = 0;

            //功能码暂存
            byte temp_func = 0;

            //数据暂存
            byte[] get_data = new byte[BYTE_CODE_MAX];

            //数据显示
            string[] temp_str = new string[BYTE_CODE_MAX];

            //获取接收的数据长度
            temp_len = queue.get_lenth();

            if (temp_len > 0)
            {
                //弹出数据
                queue.Delete_Queue(get_data, temp_len);    
                
                //以下为数据解析
                //先判断 RTU ASCII
                //功能码 03 06
                //crc

                if (get_data[0] != ':')//RTU
                {
                    if (get_data[1] < 0x80)//正常功能码
                    {
                        sum_RTU_crc = cal_crc.Div_Data_Check_Crc(get_data, temp_len - 2);
                        rec_RTU_crc = ((get_data[temp_len - 2] << 8) + get_data[temp_len - 1]);

                        if (sum_RTU_crc == rec_RTU_crc)
                        {
                            //区分功能码
                            temp_func = get_data[1];

                            switch (temp_func)
                            {
                                // 00 广播地址 从机不会有回应
                                case 00: break;
                                case 01: break;
                                case 02: break;
                                case 03: Data_Byte_To_String(get_data, temp_str, temp_len, textBox9); Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_RS, textBox10); break;
                                case 04: break;
                                case 05: break;
                                case 06: Data_Byte_To_String(get_data, temp_str, temp_len, textBox14); Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_RS, textBox15); break;
                                case 07: break;

                                //其它功能码...

                                default:break;
                            }
                        }
                        else//CRC校验错误
                        {
                            func_code03_06_show = 1;//接收错误标识
                            Array.Clear(get_data, 0, temp_len);
                        }
                    }
                    else//错误功能码
                    {
                        func_code03_06_show = 1;//接收错误标识
                        Array.Clear(get_data, 0, temp_len);
                    }
                }
                else//ASCII
                {
                    //功能码
                    temp_func = (byte)((ascii_to_hex((byte)get_data[3]) << 4) + ascii_to_hex((byte)get_data[4]));

                    if (temp_func < 0x80)//正常功能码
                    {
                        sum_ASCII_crc = CAL_LQR(get_data, temp_len - 5);
                        rec_ASCII_crc = (byte)((ascii_to_hex((byte)get_data[temp_len - 4]) << 4) + ascii_to_hex((byte)get_data[temp_len - 3]));

                        if (sum_RTU_crc == rec_RTU_crc)
                        {
                            //区分功能码
                            temp_func = (byte)((ascii_to_hex((byte)get_data[3]) << 4) + ascii_to_hex((byte)get_data[4]));

                            switch (temp_func)
                            {
                                // 00 广播地址 从机不会有回应
                                case 00: break;
                                case 01: break;
                                case 02: break;
                                case 03: Data_Byte_To_String(get_data, temp_str, temp_len, textBox9); Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_RS, textBox10); break;
                                case 04: break;
                                case 05: break;
                                case 06: Data_Byte_To_String(get_data, temp_str, temp_len, textBox14); Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_RS, textBox15); break;
                                case 07: break;

                                //其它功能码...

                                default: break;
                            }
                            
                        }
                        else//CRC校验错误
                        {
                            func_code03_06_show = 1;//接收错误标识
                            Array.Clear(get_data, 0, temp_len);
                        }
                    }
                    else//错误功能码
                    {
                        func_code03_06_show = 1;//接收错误标识
                        Array.Clear(get_data, 0, temp_len);
                    }
                }              
            }
            else//没有接收到数据
            {
                func_code03_06_show = 1;//接收错误标识
                Array.Clear(get_data, 0, temp_len);
            }

            if (func_code03_06_show == 1)//错误标识显示
            {
                if ((textBox8.Text != " ") && (textBox9.Text == " "))//03 发送有数据 接收没有数据
                {
                    Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_RF, textBox10);//信息显示
                }
                if ((textBox13.Text != " ") && (textBox14.Text == " "))//06 发送有数据 接收没有数据
                {
                    Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_RF, textBox15);//信息显示
                }
                func_code03_06_show = 0;
            }
        }

        //textbox输入数据限制
        //暂时用不上
        public void data_in_from_textbox_limit()
        {
            //设备地址限制
            if ((Convert.ToByte(textBox2.Text, 10) >= 0) && (Convert.ToByte(textBox2.Text, 10) <= 247)
                && (Convert.ToUInt16(textBox6.Text, 10) >= 0) && (Convert.ToUInt16(textBox6.Text, 10) <= 65535)
                && (Convert.ToUInt16(textBox7.Text, 10) >= 1) && (Convert.ToUInt16(textBox7.Text, 10) <= 65535)
                && (Convert.ToUInt16(textBox11.Text, 10) >= 0) && (Convert.ToUInt16(textBox11.Text, 10) <= 65535)
                && (Convert.ToUInt16(textBox12.Text, 10) >= 0) && (Convert.ToUInt16(textBox12.Text, 10) <= 65535))
            {
              
            }
            else
            {
              
            }
        }

        //发送数据测试 03 06
        /*
         格式：
         * RTU方式：主机 功能码 03 从某个寄存器地址开始读出N个内容
         *  从机地址 功能码 寄存器地址H  寄存器地址L 数量H  数量L 校验码H 校验码L (CRC校验)
         *  
         * ASCII方式：以上类似只是每个数据拆分成两个数据传输(除帧头(:)、帧尾(\r \n))
         * : 从机地址 功能码 寄存器地址H  寄存器地址L 数量H  数量L 校验码H 校验码L (LRC校验) \r \n
         */
        private void button4_Click(object sender, EventArgs e)
        {
            set_times_ms = Convert.ToUInt16(textBox16.Text, 10);            //获取时间
            timer1.Start();                                                 //开始定时
            func_0306_deal_first(textBox2, textBox6, textBox7, 0x03, radioButton2, serialPort1, textBox8);
            Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_TS, textBox10);          
        }

        //06 从某个寄存器地址开始写入一个数据 
        //其它同 03 
        private void button5_Click(object sender, EventArgs e)
        {
            set_times_ms = Convert.ToUInt16(textBox16.Text, 10);             //获取时间
            timer1.Start();                                                  //开始定时
            func_0306_deal_first(textBox2, textBox11, textBox12, 0x06, radioButton2, serialPort1, textBox13);
            Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_TS, textBox15);
        }

        public void clear_func_03()
        {
            textBox8.Text = " ";
            textBox9.Text = " ";           
        }

        public void clear_func_06()
        {
            textBox13.Text = " ";
            textBox14.Text = " ";
        }

        // 03功能码清除内容
        private void button8_Click(object sender, EventArgs e)
        {
            clear_func_03();
            Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_TE, textBox10);
        }

        // 06功能码清除内容
        private void button9_Click(object sender, EventArgs e)
        {
            clear_func_06();
            Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_TE, textBox15);
        }

        //关于软件
        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("'MODBUS'软件实现MODBUS协议的功能码03/06；\n MODBUS协议通信方式采用:RTU/ASCII；\n MODBUS协议通信载体采用:UART、TCP/IP(暂未开放)；\n 串口配置:下位机采用9600(波特率)测试通过! \n 数据输入限制(理论): \n 设备地址:0->247,响应时间(100ms):1->65535, \n 寄存器地址:0->65535,数量:1->65535,数值:0->65535,详见MODBUS协议! \n 软件会持续更新!\n 作者:廖玥英 \n 联系方式(QQ):1092003911", "关于MODBUS");
        }

        //更多功能码相关操作
        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("其它功能暂未实现，敬请期待!!!","关于MODBUS");
        }

        //
        enum func_code03_06_flag : byte
        {
            FUNC_CODE_0306_DF = 0,//默认
            FUNC_CODE_0306_TS = 1,//发送成功
            FUNC_CODE_0306_TF = 2,//发送失败
            FUNC_CODE_0306_RS = 3,//接收成功
            FUNC_CODE_0306_RF = 4,//接收失败
            FUNC_CODE_0306_TE = 5,//可以通信
            FUNC_CODE_0306_ERR = 6,//输入数据非法
            FUNC_CODE_0306_MAX,
        };

        //03 06功能码 数据接收状态改变显示
        //textbox10 textbox15
        public void Rec_Data_State_Show(byte num ,TextBox textbox_show)
        {
            string str = " ";

            switch (num)
            {
                case 00: str = "Modbus基本配置 -> 通信载体、通信方式未选择，不能通信!";  break;
                case 01: str = "Modbus数据发送成功!";                                 break;
                case 02: str = "Modbus数据发送失败，请检查基本配置!";                 break;
                case 03: str = "Modbus数据接收成功!";                                 break;
                case 04: str = "Modbus数据接收失败，超时或无响应!";                   break;
                case 05: str = "Modbus可以通信";                                      break;
                case 06: str = "Modbus输入数据非法";                                  break;
                default:                                                              break;
            }
            textbox_show.Text = str;       
        }

        //接收数据测试

        //串口操作相关实现
        /*功能实现区域#################################################################################开始*/

        //线程处理函数
        public void Serial_RecData_Deal()
        {

        }

        public void Div_Deal_Rec_Data()
        {
            func_0306_deal_recdata_first();           
        }

        //定时器处理函数
        //需要在界面设置一下时基 
        //暂时没有用到
        //时基 20ms以上比较准确!!!
        private void timer1_Tick(object sender, EventArgs e)
        {
            get_times_ms++;
            
            if ((textBox14.Text == " ")||(textBox9.Text == " "))
            {
                if (get_times_ms == set_times_ms)
                {
                    timer1.Stop();
                    get_times_ms = 0;
                    func_code03_06_show = 2;
                }
            }
            if (func_code03_06_show == 2)
            {
                if ((textBox8.Text != " ") && (textBox9.Text == " "))//03 发送有数据 接收没有数据
                {
                    Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_RF, textBox10);//信息显示
                }
                if ((textBox13.Text != " ") && (textBox14.Text == " "))//06 发送有数据 接收没有数据
                {
                    Rec_Data_State_Show((byte)func_code03_06_flag.FUNC_CODE_0306_RF, textBox15);//信息显示
                }
                func_code03_06_show = 0;
            }
        }

        //委托实际函数
        public void My_Serial_Rece_ShowBox()
        {
            Div_Deal_Rec_Data();
        }

        private void Div_Rece_Data(object sender, SerialDataReceivedEventArgs e)
        {
            int rec_temp_len = 0;

            //线程创建
            ThreadStart entry = new ThreadStart(Serial_RecData_Deal);
            Thread WorkThread = new Thread(entry);

            //不能在这里开启线程 
            //接收不到第一次数据
            //WorkThread.Start();

            if (serialPort1.IsOpen)
            {
                try
                {
                    rec_temp_len = serialPort1.BytesToRead;

                    serialPort1.Read(rec_data, 0, rec_temp_len);
                    queue.Insert_Queue(rec_data, rec_temp_len);     //数据入栈

                   // WorkThread.Start();

                    serialPort1.DiscardInBuffer();                  //将上次接收的数据丢弃方便下一次接收

                    this.Invoke(My_Serial_Rece_Show, null);         //委托                   
                }
                catch
                {

                }
            }
        }

        //自动扫描串口
        private void Div_Auto_Search_Port(SerialPort Myport, ComboBox MyBox, int num)
        {
            string str = " ";

            MyBox.Items.Clear();//清除之前的内容

            for (int i = 1; i < num; i++)//没有CMO0
            {
                try
                {
                    str = "COM" + i.ToString();
                    Myport.PortName = str;
                    Myport.Open();
                    MyBox.Items.Add(str);
                    Myport.Close();
                }
                catch
                {
                }
            }
        }

        //打开串口
        private void Div_Check_Serail_IsOpen(SerialPort Myport, ComboBox MyBox, Button MyBon)
        {
            if (MyBox.Text != " ")//确保已经选好了COM口
            {
                if (Myport.IsOpen)//关闭
                {
                    try
                    {
                        Myport.Close();
                        MyBon.Text = "打开串口";
                        //提示信息显示
                        textBox1.Text = "Close!!!";
                        button1.Text = "扫描端口";

                        func_code03_06_show = 3;                
                    }
                    catch
                    { }
                }
                else
                {
                    try
                    {
                        Myport.PortName = MyBox.Text;
                        Myport.Open();
                        MyBon.Text = "关闭串口";
                        func_code03_06_show = 4;

                        //提示信息显示
                        textBox1.Text = MyBox.Text + "," + Myport.BaudRate.ToString() + "," + "N" + "," + Myport.DataBits.ToString() + "," + Myport.StopBits.ToString();
                    }
                    catch
                    { }
                }
            }
            else
            {
                MessageBox.Show("请选择正确COM口!");
            }
         
        }

        //字节数组转换成字符串数组
        public void Data_Byte_To_String(byte[] byte_in, string[] str_out,int len_in,TextBox textbox_shpw)
        {
            //清空上一次数据
            textbox_shpw.Text = " ";

            for (int i = 0; i < len_in; i++)
            {
                //转换为大写十六进制字符串
                str_out[i] = Convert.ToString(byte_in[i], 16).ToUpper();                               
                //字符串显示
                textbox_shpw.AppendText((str_out[i].Length == 1 ? ("0" + str_out[i]) : str_out[i]) + " ");
            }
        }

        //LQR
        public byte CAL_LQR(byte[] paddr,int cnt)
        {
            int i = 0;
            byte sum = 0;

            for (i = 1; i < cnt; i++)
            {
                sum += paddr[i];
            }

            sum = (byte)((~sum) + 1);

            return (sum);
        }

        /*功能实现区域#################################################################################结束*/

        /*辅助功能实现区域#################################################################################开始*/

        /*************************************************************************************************************LOOP_QUEUE*/

        public class loop_queue_list<T>
        {
            public int LOOP_QUEUE_SIZE_MAX;     //数组容量最大值
            public int head_pointer;            //头指针
            public int tail_pointer;            //尾指针
            public T[] array;                   //数组

            //构造函数
            public loop_queue_list(int size)
            {
                this.LOOP_QUEUE_SIZE_MAX = size;
                this.head_pointer = 0;
                this.tail_pointer = 0;
                this.array = new T[size];
            }

            public bool Insert_Queue(T value)
            {
                if ((tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX == head_pointer)//满了
                {
                    return false;
                }
                else
                {
                    array[tail_pointer] = value;
                    tail_pointer = (tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    return true;
                }
            }

            public void Insert_Queue(T[] pdat, int len)
            {
                for (int i = 0; i < len; i++)
                {
                    if ((tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX == head_pointer)//满了
                    {
                        return;
                    }
                    else
                    {
                        array[tail_pointer] = pdat[i];
                        tail_pointer = (tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    }
                }
            }

            public T Delete_Queue()
            {
                T value = default(T);

                if (tail_pointer == head_pointer)//空了
                {
                    return value;
                }
                else
                {
                    value = array[head_pointer];
                    head_pointer = (head_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    return value;
                }
            }

            public void Delete_Queue(T[] pdat, int len)
            {
                for (int i = 0; i < len; i++)
                {
                    if (tail_pointer == head_pointer)//空了
                    {
                        return;
                    }
                    else
                    {
                        pdat[i] = array[head_pointer];
                        head_pointer = (head_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    }
                }
            }

            public int get_lenth()
            {
                return ((tail_pointer + LOOP_QUEUE_SIZE_MAX - head_pointer) % LOOP_QUEUE_SIZE_MAX);
            }
        }

        /*************************************************************************************************************CRC*/

        public class cal_check_list
        {

           //构造函数
            public cal_check_list()
            {
                
            }

            /* CRC 高位字节值表 */
            byte[] auchCRCHi = new byte[256]{
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
                0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
                0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
                0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
        } ;

            /* CRC低位字节值表*/
            byte[] auchCRCLo = new byte[256]{
                0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06,
                0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD,
                0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
                0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A,
                0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 0x14, 0xD4,
                0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
                0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3,
                0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4,
                0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
                0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29,
                0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED,
                0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
                0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60,
                0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67,
                0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
                0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68,
                0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E,
                0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
                0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71,
                0x70, 0xB0, 0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92,
                0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
                0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B,
                0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B,
                0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
                0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42,
                0x43, 0x83, 0x41, 0x81, 0x80, 0x40
        } ;

            public int Div_Data_Check_Crc(byte[] puchMsg, int usDataLen)
            {
                byte uchCRCHi = 0xFF ;                           // 高CRC字节初始化
                byte uchCRCLo = 0xFF ;                           // 低CRC 字节初始化
                long uIndex ; 		                             // CRC循环中的索引

                for (long i = 0; i < usDataLen; i++)
                {
                    uIndex = uchCRCHi ^ puchMsg[i]; 	    // 计算CRC
                    uchCRCHi = (byte)(uchCRCLo ^ auchCRCHi[uIndex]);
                    uchCRCLo = (byte)auchCRCLo[uIndex];
                }

                return ( uchCRCHi << 8 | uchCRCLo ) ;
            }

      }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }


        /*辅助功能实现区域#################################################################################结束*/
    }
}
